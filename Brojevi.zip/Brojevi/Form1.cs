﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Brojevi
{
    public partial class Brojevi : Form
    {
        public Brojevi()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            listBox3.Items.Clear();
            try
            {
                int a = Convert.ToInt32(textBox1.Text);
                int b = Convert.ToInt32(textBox2.Text);
                int i = 0;
                int nule = 0;
                float prosek = 0;
                StreamReader f = new StreamReader("brojevi.txt");
                while (!f.EndOfStream)
                {
                    int br = Convert.ToInt32(f.ReadLine());
                    if (br > a && br < b)
                        listBox1.Items.Add(br.ToString());
                    prosek = prosek + br;
                    i++;
                    if (br == 0) nule++;
                    if (br > 0)
                        listBox2.Items.Add(br.ToString());
                    if (br < 0)
                        listBox3.Items.Add(br.ToString());
                }
                f.Close();
                textBox3.Text = Convert.ToString(prosek / i);
                textBox4.Text = Convert.ToString(nule);
            }
            catch (Exception izuzetak)
            {
                MessageBox.Show(izuzetak.Message);
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
