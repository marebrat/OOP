﻿using System;
using System.Windows.Forms;

namespace Kvadrat
{
    public partial class Kvadrat : Form
    {
        public Kvadrat()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double x1 = Convert.ToDouble(textBox1.Text);
            double y1 = Convert.ToDouble(textBox2.Text);
            double x2 = Convert.ToDouble(textBox3.Text);
            double y2 = Convert.ToDouble(textBox4.Text);

            double stranica = Math.Abs(x1 - x2);
            double dijagonala = Math.Sqrt(Math.Pow(x1 - x2, 2) + Math.Pow(y1 - y2, 2));

            if (checkBox1.Checked)
            {
                double povrsina = Math.Pow(stranica, 2);
                double obim = 4 * stranica;
                textBox5.Text = obim.ToString();
                textBox6.Text = povrsina.ToString();
            }
            else
            {
                double povrsina = Math.Pow(dijagonala, 2) / 2;
                double obim = 2 * dijagonala * Math.Sqrt(2);
                textBox5.Text = obim.ToString();
                textBox6.Text = povrsina.ToString();
            }
        }
    }
}
