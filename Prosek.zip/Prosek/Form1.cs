﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prosek
{
    public partial class Prosek : Form
    {
        public Prosek()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double P = 0, a, c;
            int b = 0;
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            try
            {
                StreamReader f = new StreamReader("brojevi.txt");
                while (!f.EndOfStream)
                {
                    a = Convert.ToDouble(f.ReadLine());
                    listBox1.Items.Add(Convert.ToString(a));
                    P = P + a;
                    b++;
                }
                f.Close();

                P = P / b;
                textBox1.Text = Convert.ToString(P);

                f = new StreamReader("brojevi.txt");
                while (!f.EndOfStream)
                {
                    c = Convert.ToDouble(f.ReadLine());
                    if (c > P)
                        listBox2.Items.Add(Convert.ToString(c));
                }
                f.Close();
            }
            catch (Exception greska)
            {
                MessageBox.Show(greska.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
